# main.py
print("¡Hola Mundo desde GitHub Actions en Python!")
